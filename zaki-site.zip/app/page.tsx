"use client"

import ZakLogo from "@/components/zak-logo-simple"
import { ThemeToggle } from "@/components/theme-toggle"
import { LanguageToggle } from "@/components/language-toggle"
import Image from "next/image"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import SocialIcons from "@/components/social-icons"
import CVSection from "@/components/cv-section"
import SkillIcon from "@/components/skill-icon"
import ContactQR from "@/components/contact-qr"
import ContactForm from "@/components/contact-form"
import { Briefcase, Code, Palette, Phone, Mail } from "lucide-react"
import { useLanguage } from "@/context/language-context"

export default function Home() {
  const { t, language } = useLanguage()

  const programmingSkills = [
    { name: "Node.js", icon: "/icons/nodejs.png" },
    { name: "JavaScript", icon: "/icons/javascript.png" },
    { name: "TypeScript", icon: "/icons/typescript.png" },
    { name: "SQL", icon: "/icons/sql.png" },
    { name: "HTML", icon: "/icons/html.png" },
    { name: "CSS", icon: "/icons/css.jpeg" },
    { name: "Power BI", icon: "/icons/powerbi.png" },
    { name: "Data Analysis", icon: "/icons/data-analysis.jpeg" },
    { name: "Google Apps Script", icon: "/icons/google-apps-script.jpeg" },
    { name: "Web3", icon: "/icons/web3.png" },
  ]

  const designSkills = [
    { name: "Photoshop", icon: "/icons/photoshop.png" },
    { name: "Illustrator", icon: "/icons/illustrator.jpeg" },
    { name: "InDesign", icon: "/icons/indesign.png" },
    { name: "Maya", icon: "/icons/maya.png" },
    { name: "3D Max", icon: "/icons/3dmax.jpeg" },
  ]

  const textAlignClass = language === "ar" ? "text-right" : "text-left"
  const flexDirClass = language === "ar" ? "flex-row" : "flex-row-reverse"

  return (
    <main className="flex flex-col items-center max-w-4xl mx-auto w-full">
      <div className="w-full flex justify-between items-center py-4">
        <ZakLogo size="md" />
        <div className="flex items-center gap-2">
          <LanguageToggle />
          <ThemeToggle />
        </div>
      </div>

      <div className="w-full bg-white dark:bg-slate-800 rounded-xl shadow-md overflow-hidden mb-8">
        <div className="md:flex">
          <div className="md:shrink-0 bg-gradient-to-br from-purple-500 to-pink-500 p-6 flex flex-col items-center justify-center">
            <div className="w-32 h-32 md:w-40 md:h-40 rounded-full overflow-hidden border-4 border-white shadow-lg mb-4">
              <Image
                src="/images/profile.png"
                alt={t("name")}
                width={200}
                height={200}
                className="object-cover w-full h-full"
                priority
              />
            </div>
            <ContactQR />
          </div>

          <div className="p-6 md:p-8">
            <div className={`text-center md:${textAlignClass}`}>
              <h1 className="text-3xl md:text-4xl font-bold mb-1 text-slate-800 dark:text-slate-100">{t("name")}</h1>
              <div className="text-xl text-purple-600 dark:text-purple-400 mb-4">{t("job_title")}</div>

              <div className={`flex flex-col gap-2 text-slate-600 dark:text-slate-300 mb-4`}>
                <div
                  className={`flex items-center gap-2 justify-center md:justify-${language === "ar" ? "start" : "end"}`}
                >
                  <Phone className="w-4 h-4" />
                  <span>{t("phone")}</span>
                </div>
                <div
                  className={`flex items-center gap-2 justify-center md:justify-${language === "ar" ? "start" : "end"}`}
                >
                  <Briefcase className="w-4 h-4" />
                  <span>{t("current_job")}</span>
                </div>
              </div>
            </div>

            <p className={`text-slate-700 dark:text-slate-300 mb-6 text-lg ${textAlignClass}`}>{t("bio")}</p>

            <div className={`flex flex-wrap gap-2 justify-center md:justify-${language === "ar" ? "start" : "end"}`}>
              <Badge className="bg-purple-600 hover:bg-purple-700">{t("web_developer")}</Badge>
              <Badge className="bg-pink-600 hover:bg-pink-700">{t("software_engineer")}</Badge>
              <Badge className="bg-yellow-600 hover:bg-yellow-700">{t("ui_designer")}</Badge>
              <Badge className="bg-blue-600 hover:bg-blue-700">{t("data_analyst")}</Badge>
            </div>
          </div>
        </div>
      </div>

      <div className="w-full grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
        {/* قسم الوظيفة الحالية */}
        <Card className="bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm border border-slate-200 dark:border-slate-700">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Briefcase className="w-5 h-5 text-purple-600 dark:text-purple-400" />
              <span>{t("current_job_section")}</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className={`mb-4 text-slate-700 dark:text-slate-300 ${textAlignClass}`}>
              {t("current_job_description")}
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {programmingSkills.slice(0, 6).map((skill) => (
                <SkillIcon key={skill.name} name={skill.name} icon={skill.icon} />
              ))}
            </div>
          </CardContent>
        </Card>

        {/* قسم الهواية */}
        <Card className="bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm border border-slate-200 dark:border-slate-700">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Palette className="w-5 h-5 text-pink-600 dark:text-pink-400" />
              <span>{t("hobby_section")}</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className={`mb-4 text-slate-700 dark:text-slate-300 ${textAlignClass}`}>{t("hobby_description")}</p>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {designSkills.map((skill) => (
                <SkillIcon key={skill.name} name={skill.name} icon={skill.icon} />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="w-full mb-8">
        <CVSection title={t("programming_skills")} icon={<Code className="w-5 h-5" />}>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
            {programmingSkills.map((skill) => (
              <SkillIcon key={skill.name} name={skill.name} icon={skill.icon} />
            ))}
          </div>
        </CVSection>
      </div>

      <Card className="w-full mb-8 bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm border border-slate-200 dark:border-slate-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mail className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            <span>{t("contact_me")}</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ContactForm />
        </CardContent>
      </Card>

      <footer className="w-full mt-auto py-6 border-t border-slate-200 dark:border-slate-700">
        <SocialIcons className="mb-4" />
        <div className="text-sm text-slate-500 dark:text-slate-400 text-center">
          &copy; {new Date().getFullYear()} {t("name")}. {t("rights_reserved")}.
        </div>
      </footer>
    </main>
  )
}
