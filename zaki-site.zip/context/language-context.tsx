"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

type Language = "ar" | "en"

interface LanguageContextType {
  language: Language
  setLanguage: (language: Language) => void
  t: (key: string) => string
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

interface LanguageProviderProps {
  children: ReactNode
}

export function LanguageProvider({ children }: LanguageProviderProps) {
  const [language, setLanguage] = useState<Language>("ar")

  useEffect(() => {
    // Update document direction based on language
    document.documentElement.dir = language === "ar" ? "rtl" : "ltr"
    document.documentElement.lang = language
  }, [language])

  const t = (key: string): string => {
    return translations[language][key] || key
  }

  return <LanguageContext.Provider value={{ language, setLanguage, t }}>{children}</LanguageContext.Provider>
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}

// Translations
const translations = {
  ar: {
    // Header
    name: "زكي عطا",
    job_title: "أخصائي نظم ومعلومات",
    phone: "01021088836",
    current_job: "أخصائي نظم ومعلومات قطاعات القناة - خبرة 8 سنوات",
    bio: "أعمل على تحويل الأفكار المعقدة إلى أدوات بسيطة وفعالة تخدم المستخدم وتراعي الجودة. شغفي بالتفاصيل والهيكلة النظيفة بيخليني أتعامل مع كل مشروع كأنه لوحة فنية.",

    // Badges
    web_developer: "مطور ويب",
    software_engineer: "مهندس برمجيات",
    ui_designer: "مصمم واجهات",
    data_analyst: "محلل بيانات",

    // Sections
    current_job_section: "الوظيفة الحالية",
    current_job_description:
      "أخصائي نظم ومعلومات قطاعات القناة مع خبرة 8 سنوات في تطوير وإدارة أنظمة المعلومات. أقوم بتحليل البيانات وتطوير الحلول البرمجية لتحسين كفاءة العمل وتسهيل اتخاذ القرارات.",
    hobby_section: "الهواية",
    hobby_description:
      "التصميم الجرافيكي - خبرة 15 سنة. شغفي بالتصميم يمكنني من إنشاء تصاميم إبداعية وجذابة تجمع بين الجمال والوظيفة، سواء كانت تصاميم ثنائية أو ثلاثية الأبعاد.",
    programming_skills: "المهارات البرمجية",

    // Contact form
    contact_me: "تواصل معي",
    name_field: "الاسم",
    email_field: "البريد الإلكتروني",
    subject_field: "الموضوع",
    message_field: "الرسالة",
    send_message: "إرسال الرسالة",
    sending: "جاري الإرسال...",
    message_sent: "تم إرسال رسالتك بنجاح! سنتواصل معك قريبًا.",
    name_placeholder: "الاسم الكامل",
    email_placeholder: "example@example.com",
    subject_placeholder: "موضوع الرسالة",
    message_placeholder: "اكتب رسالتك هنا...",

    // Footer
    rights_reserved: "جميع الحقوق محفوظة",
    scan_to_contact: "امسح للاتصال",
  },
  en: {
    // Header
    name: "Zaki Atta",
    job_title: "Information Systems Specialist",
    phone: "01021088836",
    current_job: "Information Systems Specialist in Canal Sectors - 8 years experience",
    bio: "I work on transforming complex ideas into simple and effective tools that serve the user and take quality into account. My passion for details and clean structure makes me treat each project as a work of art.",

    // Badges
    web_developer: "Web Developer",
    software_engineer: "Software Engineer",
    ui_designer: "UI Designer",
    data_analyst: "Data Analyst",

    // Sections
    current_job_section: "Current Job",
    current_job_description:
      "Information Systems Specialist in Canal Sectors with 8 years of experience in developing and managing information systems. I analyze data and develop software solutions to improve work efficiency and facilitate decision-making.",
    hobby_section: "Hobby",
    hobby_description:
      "Graphic Design - 15 years experience. My passion for design enables me to create creative and attractive designs that combine beauty and function, whether they are 2D or 3D designs.",
    programming_skills: "Programming Skills",

    // Contact form
    contact_me: "Contact Me",
    name_field: "Name",
    email_field: "Email",
    subject_field: "Subject",
    message_field: "Message",
    send_message: "Send Message",
    sending: "Sending...",
    message_sent: "Your message has been sent successfully! We will contact you soon.",
    name_placeholder: "Full Name",
    email_placeholder: "example@example.com",
    subject_placeholder: "Message Subject",
    message_placeholder: "Write your message here...",

    // Footer
    rights_reserved: "All rights reserved",
    scan_to_contact: "Scan to contact",
  },
}
