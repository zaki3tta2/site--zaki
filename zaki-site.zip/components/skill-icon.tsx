import { cn } from "@/lib/utils"
import Image from "next/image"
import type { HTMLAttributes } from "react"

interface SkillIconProps extends HTMLAttributes<HTMLDivElement> {
  name: string
  icon: string
  className?: string
}

export default function SkillIcon({ name, icon, className, ...props }: SkillIconProps) {
  return (
    <div
      className={cn(
        "flex flex-col items-center gap-2 p-3 rounded-lg bg-white/50 dark:bg-slate-800/50 backdrop-blur-sm border border-slate-200 dark:border-slate-700 transition-all hover:shadow-md hover:-translate-y-1",
        className,
      )}
      {...props}
    >
      <div className="w-12 h-12 flex items-center justify-center">
        <Image
          src={icon || "/placeholder.svg"}
          alt={name}
          width={48}
          height={48}
          className="object-contain w-full h-full"
        />
      </div>
      <span className="text-sm font-medium text-slate-700 dark:text-slate-300">{name}</span>
    </div>
  )
}
