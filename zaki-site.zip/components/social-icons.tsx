"use client"

import { Facebook, Github, Linkedin, MessageCircle, Phone, Send } from "lucide-react"
import Link from "next/link"
import { cn } from "@/lib/utils"
import { useLanguage } from "@/context/language-context"

interface SocialIconsProps {
  className?: string
}

export default function SocialIcons({ className }: SocialIconsProps) {
  const { language } = useLanguage()

  const socialLinks = [
    {
      href: "https://www.facebook.com/zaki.atta/",
      icon: <Facebook className="w-5 h-5" />,
      label: "Facebook",
      color: "hover:text-[#1877F2]",
    },
    {
      href: "https://wa.me/201021088836",
      icon: <MessageCircle className="w-5 h-5" />,
      label: "WhatsApp",
      color: "hover:text-[#25D366]",
    },
    {
      href: "https://t.me/01021088836",
      icon: <Send className="w-5 h-5" />,
      label: "Telegram",
      color: "hover:text-[#0088cc]",
    },
    {
      href: "https://www.linkedin.com/in/zakiatta",
      icon: <Linkedin className="w-5 h-5" />,
      label: "LinkedIn",
      color: "hover:text-[#0A66C2]",
    },
    {
      href: "https://github.com/zakiatta",
      icon: <Github className="w-5 h-5" />,
      label: "GitHub",
      color: "hover:text-[#24292e]",
    },
    {
      href: "tel:+201021088836",
      icon: <Phone className="w-5 h-5" />,
      label: "Phone",
      color: "hover:text-[#6366F1]",
    },
  ]

  return (
    <div className={cn("flex gap-4 justify-center", className)}>
      {socialLinks.map((link) => (
        <Link
          key={link.label}
          href={link.href}
          target="_blank"
          rel="noopener noreferrer"
          className={cn(
            "w-10 h-10 flex items-center justify-center rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 transition-all hover:shadow-md",
            link.color,
          )}
          aria-label={link.label}
        >
          {link.icon}
        </Link>
      ))}
    </div>
  )
}
