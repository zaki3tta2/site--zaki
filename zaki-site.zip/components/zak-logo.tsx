import { cn } from "@/lib/utils"

interface ZakLogoProps {
  className?: string
  size?: "sm" | "md" | "lg"
}

export default function ZakLogo({ className, size = "md" }: ZakLogoProps) {
  const sizeClasses = {
    sm: "text-xl",
    md: "text-2xl",
    lg: "text-4xl",
  }

  return (
    <div className={cn("font-bold relative inline-block", sizeClasses[size], className)}>
      <span className="bg-gradient-to-r from-purple-600 to-pink-600 text-transparent bg-clip-text">Z</span>
      <span className="bg-gradient-to-r from-pink-600 to-yellow-500 text-transparent bg-clip-text">A</span>
      <span className="bg-gradient-to-r from-yellow-500 to-purple-600 text-transparent bg-clip-text">K</span>
      <div className="absolute -bottom-1 left-0 w-full h-[2px] bg-gradient-to-r from-purple-600 via-pink-600 to-yellow-500"></div>
    </div>
  )
}
