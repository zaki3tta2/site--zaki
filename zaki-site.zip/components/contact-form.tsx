"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { sendContactForm } from "@/app/actions"
import { Loader2, CheckCircle } from "lucide-react"
import { useLanguage } from "@/context/language-context"

export default function ContactForm() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const { t } = useLanguage()

  async function handleSubmit(formData: FormData) {
    setIsSubmitting(true)
    setError(null)

    try {
      await sendContactForm(formData)
      setIsSuccess(true)
      // Reset form
      const form = document.getElementById("contact-form") as HTMLFormElement
      form?.reset()
    } catch (err) {
      setError("حدث خطأ أثناء إرسال الرسالة. يرجى المحاولة مرة أخرى.")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <form id="contact-form" action={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
            {t("name_field")}
          </label>
          <Input id="name" name="name" placeholder={t("name_placeholder")} required className="w-full" />
        </div>
        <div>
          <label htmlFor="email" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
            {t("email_field")}
          </label>
          <Input
            id="email"
            name="email"
            type="email"
            placeholder={t("email_placeholder")}
            required
            className="w-full"
          />
        </div>
      </div>
      <div>
        <label htmlFor="subject" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
          {t("subject_field")}
        </label>
        <Input id="subject" name="subject" placeholder={t("subject_placeholder")} required className="w-full" />
      </div>
      <div>
        <label htmlFor="message" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
          {t("message_field")}
        </label>
        <Textarea
          id="message"
          name="message"
          placeholder={t("message_placeholder")}
          rows={5}
          required
          className="w-full"
        />
      </div>

      {error && <div className="text-red-500 text-sm">{error}</div>}

      {isSuccess ? (
        <div className="flex items-center gap-2 text-green-600 dark:text-green-400 p-3 bg-green-50 dark:bg-green-900/20 rounded-md">
          <CheckCircle className="w-5 h-5" />
          <span>{t("message_sent")}</span>
        </div>
      ) : (
        <Button type="submit" disabled={isSubmitting} className="w-full bg-purple-600 hover:bg-purple-700 text-white">
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              {t("sending")}
            </>
          ) : (
            t("send_message")
          )}
        </Button>
      )}
    </form>
  )
}
