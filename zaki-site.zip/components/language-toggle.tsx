"use client"

import { useLanguage } from "@/context/language-context"
import { Button } from "@/components/ui/button"
import { Globe } from "lucide-react"

export function LanguageToggle() {
  const { language, setLanguage } = useLanguage()

  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={() => setLanguage(language === "ar" ? "en" : "ar")}
      className="w-9 h-9 rounded-full transition-colors hover:bg-slate-200 dark:hover:bg-slate-800"
      aria-label={language === "ar" ? "Switch to English" : "التبديل إلى العربية"}
    >
      <Globe className="h-5 w-5" />
      <span className="sr-only">{language === "ar" ? "English" : "العربية"}</span>
    </Button>
  )
}
