"use client"

import { useEffect, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { QRCodeSVG } from "qrcode.react"
import { useLanguage } from "@/context/language-context"

export default function ContactQR() {
  const [mounted, setMounted] = useState(false)
  const { t } = useLanguage()

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return (
      <Card className="w-full max-w-[200px] h-[200px] flex items-center justify-center bg-white dark:bg-slate-800">
        <div className="w-full h-full animate-pulse bg-slate-200 dark:bg-slate-700"></div>
      </Card>
    )
  }

  const vCardData = `BEGIN:VCARD
VERSION:3.0
N:Atta;Zaki;;;
FN:Zaki Atta
TEL;TYPE=CELL:01021088836
TITLE:Information Systems Specialist
EMAIL:zakiatta@example.com
URL:https://zakiatta.com
END:VCARD`

  return (
    <Card className="w-full max-w-[200px] bg-white dark:bg-slate-800 p-4">
      <CardContent className="p-0 flex flex-col items-center gap-2">
        <QRCodeSVG
          value={vCardData}
          size={180}
          bgColor={"#FFFFFF"}
          fgColor={"#000000"}
          level={"H"}
          includeMargin={false}
        />
        <span className="text-xs text-slate-500 dark:text-slate-400">{t("scan_to_contact")}</span>
      </CardContent>
    </Card>
  )
}
