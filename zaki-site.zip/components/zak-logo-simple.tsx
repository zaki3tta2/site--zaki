interface ZakLogoProps {
  className?: string
  size?: "sm" | "md" | "lg"
}

export default function ZakLogo({ className, size = "md" }: ZakLogoProps) {
  const fontSize = size === "sm" ? "text-xl" : size === "md" ? "text-2xl" : "text-4xl"

  return (
    <div className={`font-bold ${fontSize} ${className || ""}`}>
      <span className="text-purple-600">Z</span>
      <span className="text-pink-600">A</span>
      <span className="text-yellow-500">K</span>
    </div>
  )
}
