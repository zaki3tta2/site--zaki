"use client"

import type React from "react"

import { cn } from "@/lib/utils"
import type { HTMLAttributes } from "react"
import { useLanguage } from "@/context/language-context"

interface CVSectionProps extends HTMLAttributes<HTMLDivElement> {
  title: string
  icon?: React.ReactNode
  children: React.ReactNode
  className?: string
}

export default function CVSection({ title, icon, children, className, ...props }: CVSectionProps) {
  const { language } = useLanguage()
  const textAlignClass = language === "ar" ? "text-right" : "text-left"

  return (
    <div className={cn("mb-8", className)} {...props}>
      <div
        className={`flex items-center gap-2 mb-4 border-b border-slate-200 dark:border-slate-700 pb-2 ${language === "ar" ? "" : "flex-row-reverse justify-end"}`}
      >
        {icon && <div className="text-purple-600 dark:text-purple-400">{icon}</div>}
        <h2 className="text-xl font-bold text-slate-800 dark:text-slate-200">{title}</h2>
      </div>
      <div className={textAlignClass}>{children}</div>
    </div>
  )
}
